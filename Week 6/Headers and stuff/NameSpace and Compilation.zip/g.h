#include <iostream>

namespace A
{
	void g(int &a, int &b);

}
