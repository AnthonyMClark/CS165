#include<iostream>

namespace A
{
	void f(int &a, int &b);
}
